var a = prompt("enter a grade");
var b = prompt("enter b grade");
var c = prompt("enter c grade");
var d = prompt("enter d grade");
var e = prompt("enter e grade");

var v = perseInt(a)
